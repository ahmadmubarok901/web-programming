<?php

// Koneksi ke database

include 'koneksi.php';

echo $id_anggota = $_POST['id_anggota'];
echo $username =$_POST['username'];
echo $password = $_POST['password'];
$nm_lengkap = $_POST['nm_lengkap'];
$jk = $_POST['jk'];
$tgl_lahir =  $_POST['tgl_lahir'];
$no_hp = $_POST['no_hp'];
$email = $_POST['email'];
$alamat = $_POST['alamat'];
$status = $_POST['status'];

mysqli_query($koneksi, "Insert Into anggota values('$id_anggota', '$username', '$password', '$nm_lengkap', '$jk', '$tgl_lahir',
                                                     '$no_hp', '$email', '$alamat', '$status')");
   header("location:view_anggota.php");                                         





?>