<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
</head>
<body>
 <a href="input_anggota.php"> <button type="button" class="btn  btn-success"> Tambah data </button></a>
<table border="1px" class="table">
    <thead class="thead-dark">
    <tr>
        <th>ID anggota</th>
        <th>Username</th>
        <th>Password</th>
        <th>Nama Lengkap</th>
        <th>Jenis Kelamin</th>
        <th>TTL</th>
        <th>Email</th>
        <th>Alamat</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>

    </thead>
<?php

include "koneksi.php";

$query = "SELECT *from anggota";
$result = mysqli_query($koneksi, $query);

while($row = mysqli_fetch_array($result))
{ ?>

<tr>
    <td><?php echo $row['id_anggota']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['password']; ?></td>
    <td><?php echo $row['nm_lengkap']; ?></td>
    <td><?php echo $row['jk']; ?></td>
    <td><?php echo $row['tgl_lahir']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['alamat']; ?></td>
    <td><?php echo $row['status']; ?></td>
    <td> <a href="edit_anggota.php?id=<?php echo $row['id_anggota'];  ?>">Edit</a>
     <a href="delete_anggota.php?id=<?php echo $row['id_anggota'];  ?>">Hapus</a>  </td>
</tr>
<?php }


?>

</table>

</body>
</html>