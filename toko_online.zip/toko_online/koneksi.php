<?php
$host = "localhost";
$user = "root";
$pwd  = "";
$db_nm = "db_tkonline";

$koneksi = mysqli_connect($host, $user, $pwd, $db_nm );
if (!$koneksi) {
    die ("koneksi gagal : ". mysqli_connect_error());
}
?>