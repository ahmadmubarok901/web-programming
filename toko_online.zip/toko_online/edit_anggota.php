<?php

include "koneksi.php";
$id=$_GET['id'];


$query = mysqli_query($koneksi, "select *from anggota where id_anggota = '$id'" );
while ($data=mysqli_fetch_array($query)) { ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
<title>Document</title>
</head>
<body>

    <form action="update_anggota.php" method="POST">
        <span>ID  Anggota</span>
        <input class="form-control" type="text"  value="<?php echo $data['id_anggota']; ?>"  name="id_anggota"> <br>
        <span>Usernama</span>
        <input  class="form-control" type="text" value="<?php echo $data['username']; ?>"  name="username"> <br>
        <span>Password</span>
        <input  class="form-control" type="password"  value="<?php echo $data['password']; ?>" name="password"> <br>
        <span>Nama Lengkap</span>
        <input class="form-control" type="text"  value="<?php echo $data['nm_lengkap']; ?>" name="nm_lengkap"> <br>
        <span>Jenis Kelamin</span>
        <select class="form-control" name="jk" id="">
            <option value="<?php echo $data['jk']; ?>"> <?php echo $data['jk']; ?></option>
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
        </select>    <br>
        <span>Tanggal Lahir</span>
        <input class="form-control" type="date"  value="<?php echo $data['tgl_lahir']; ?>" name="tgl_lahir" id=""> <br>
        <span>No. HP</span>
        <input  class="form-control" type="text" value="<?php echo $data['no_hp']; ?>" name="no_hp"> <br>
        <span>Email</span>
        <input class="form-control" type="email"  value="<?php echo $data['email']; ?>" name="email" id=""> <br>
        <span>Alamat</span>
        <Textarea class="form-control"  value="<?php echo $data['alamat']; ?>" name="alamat"> <?php echo $data['alamat']; ?></Textarea> <br>
        <span>Status</span>
        <select class="form-control" name="status" id="">
            <option value="<?php echo $data['status']; ?>"><?php echo $data['status']; } ?></option>
            <option value="A">Admin</option>
            <option value="B">Anggota</option>
        </select> <br>
        <br>
        <input type="submit" value="Simpan">
    </form>
</body>
</html>

