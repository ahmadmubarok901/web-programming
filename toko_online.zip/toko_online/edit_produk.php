<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
<body>
<?php
include "koneksi.php";
$id=$_GET['id'];

$query = mysqli_query($koneksi, "select *from produk where id_produk = '$id'" );
while ($data=mysqli_fetch_array($query)) { ?>


        <h1>Edit Produk</h1>

      <form method="POST" action="proses_edit_produk.php" enctype="multipart/form-data" >
      <span>ID  Produk</span>
        <input class="form-control" type="text" value="<?php echo $data['id_produk'] ?>" name="id_produk" readonly> <br>
        <span>Nama Produk</span>
        <input  class="form-control" type="text"  value="<?php echo $data['nm_produk'] ?>" name="nm_produk"> <br>
        <span>Jenis Produk</span>
        <input  class="form-control" type="text"  value="<?php echo $data['jenis'] ?>" name="jenis"> <br>
            <br>
        <span>Ukuran</span>
        <input  class="form-control" type="text"  value="<?php echo $data['ukuran'] ?>" name="ukuran"> <br>
         <br>
        <span>Warna</span>
        <input  class="form-control" type="text"  value="<?php echo $data['warna'] ?>" name="warna"> <br>
        <span>Harga</span>
        <input class="form-control" type="text"  value="<?php echo $data['harga'] ?>" name="harga" id=""> <br>
        <span>Stok</span>
        <input class="form-control" type="text" value="<?php echo $data['stok'] ?>" name="stok" id=""> <br>
        <span>Keterangan</span>
        <input class="form-control" type="text"  value="<?php echo $data['deskripsi'] ?>" name="deskripsi" id=""> <br>
        <span>Gambar</span>
        <img src="gambar/<?php echo $data['url_gambar']; ?>" style="width: 120px;">
        <input class="form-control" type="file"  value="<?php echo $data['url_gambar'] ?>" name="url_gambar" id=""> <br>
        <input  class="btn btn-primary" type="submit" value="Simpan">  <input type="reset" value="Reset">
        </form>
</body>

<?php 
}

?>
</html>