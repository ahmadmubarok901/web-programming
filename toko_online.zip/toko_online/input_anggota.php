<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
<title>Document</title>
</head>
<body>
    <form action="simpan_anggota.php" method="POST">
        <span>ID  Anggota</span>
        <input class="form-control" type="text" name="id_anggota"> <br>
        <span>Usernama</span>
        <input  class="form-control" type="text" name="username"> <br>
        <span>Password</span>
        <input  class="form-control" type="password" name="password"> <br>
        <span>Nama Lengkap</span>
        <input class="form-control" type="text" name="nm_lengkap"> <br>
        <span>Jenis Kelamin</span>
        <select class="form-control" name="jk" id="">
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
        </select>    <br>
        <span>Tanggal Lahir</span>
        <input class="form-control" type="date" name="tgl_lahir" id=""> <br>
        <span>No. HP</span>
        <input  class="form-control" type="text" name="no_hp"> <br>
        <span>Email</span>
        <input class="form-control" type="email" name="email" id=""> <br>
        <span>Alamat</span>
        <Textarea class="form-control" name="alamat"></Textarea> <br>
        <span>Status</span>
        <select class="form-control" name="status" id="">
            <option value="A">Admin</option>
            <option value="B">Anggota</option>
        </select> <br>
        <br>
        <input class="form-control" type="submit" value="Simpan">
    </form>
</body>
</html>