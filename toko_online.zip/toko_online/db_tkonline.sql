-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Okt 2020 pada 11.05
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tkonline`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `anggota`
--

CREATE TABLE `anggota` (
  `id_anggota` varchar(8) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `nm_lengkap` varchar(50) DEFAULT NULL,
  `jk` char(1) DEFAULT NULL,
  `tgl_lahir` varchar(12) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `status` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `anggota`
--

INSERT INTO `anggota` (`id_anggota`, `username`, `password`, `nm_lengkap`, `jk`, `tgl_lahir`, `no_hp`, `email`, `alamat`, `status`) VALUES
('ID-001  ', 'ahmad', '123', 'ahmad mubarok', 'L', '2020-07-10', '0812000XXXX', 'ahmadmubarok941@gmail.com', ' Bandung', 'a'),
('ID-002', 'Ahmad', '1234', 'Ahmad Mubarok', 'L', '2020-06-15', '0812222227766', 'ahmadmubarok941@gmail.com', 'Alamat', 'A');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` varchar(8) NOT NULL,
  `nm_produk` varchar(50) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `ukuran` varchar(5) NOT NULL,
  `warna` varchar(15) NOT NULL,
  `harga` decimal(10,0) NOT NULL,
  `stok` int(5) NOT NULL,
  `deskripsi` text NOT NULL,
  `url_gambar` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nm_produk`, `jenis`, `ukuran`, `warna`, `harga`, `stok`, `deskripsi`, `url_gambar`) VALUES
('343qwe', 'Mouse Logitech', 'Mouse', '', '', '800000', 4, 'Mouse Gaming Logitech', '678-mouse gaming terbaik.jpg'),
('34re', 'LCD Monitor gaming', 'Monitor', '29\"', 'Hitam', '4000000', 4, 'LCD Monitor MSI', '289-monitor.jpg'),
('BR-001', 'Lenovo Thinkpad B 490', 'Laptop', '15', 'Hitam', '8000000', 4, 'Lenovo Thinpad B490 DDR4 8GB SSD 512 GB', '845-Lenovo_Yoga_730_13_L_1.jpg'),
('Id090988', 'AMD RYZEN 3 3200G PC Gaming', 'PC', '', '', '5850000', 3, '', '715-amd_pc_gaming_ryzen_3_3200g_ssd_120gb_hdd_500gb_led_20in_lengkap_full01_nta76px.png'),
('ID3213', 'Gaming Keyboard ', 'Keyboard', '', '', '0', 3, 'Gaming Keyboard', '476-gaming keyboard.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(8) NOT NULL,
  `id_anggota` varchar(8) DEFAULT NULL,
  `tanggal` varchar(15) DEFAULT NULL,
  `id_produk` varchar(8) DEFAULT NULL,
  `jumlah` int(3) DEFAULT NULL,
  `status` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_anggota`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
