<?php
include "koneksi.php";

$id = $_GET['id'];

$query = mysqli_query($koneksi, "DELETE FROM anggota where id_anggota='$id'");

header("location:view_anggota.php");


?>