<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
</head>
<br>
<a href="tambah_produk.php"> <button class="btn btn-success" > Tambah Produk</button> </a>
<table border="1px" class="table">
        <tr>
            <th>ID Produk</th>
            <th>Nama</th>
            <th>Jenis</th>
            <th>Ukuran</th>
            <th>Warna </th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Deskripsi</th>
            <th>Gambar</th>
            <th>Aksi</th>
        </tr>


<?php

include "koneksi.php";

$query = "SELECT *from produk";
$result = mysqli_query($koneksi, $query);

while($row = mysqli_fetch_array($result))
{?>

<tr>
        <td><?php echo $row['id_produk'];?></td>
        <td><?php echo $row['nm_produk'];?></td>
        <td><?php echo $row['jenis'];?></td>
        <td><?php echo $row['ukuran'];?></td>
        <td><?php echo $row['warna'];?></td>
        <td><?php echo $row['harga'];?></td>
        <td><?php echo $row['stok'];?></td>
        <td><?php echo $row['deskripsi'];?></td>
        <td style="text-align: center;"><img src="gambar/<?php echo $row['url_gambar']; ?>" style="width: 120px; height:100"></td>
        <td><a href="edit_produk.php?id=<?php echo  $row['id_produk']; ?>"> <button class="btn btn-primary"> EDIT </button></a><a href="delete_produk.php?id=<?php echo  $row['id_produk']; ?>"> <button class="btn btn-danger"> HAPUS</button> </a></td>
</tr>
<?php } ?>
</table>
