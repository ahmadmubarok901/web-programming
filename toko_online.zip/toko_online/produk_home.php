

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap core CSS -->
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
* {
  box-sizing: border-box;
}
body {
  font-family: Arial, Helvetica, sans-serif;
}
/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}
/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}
/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
.harga{ 
    color:#FF5733;
}
</style>
</head>
<body>
<div class="row">
<?php
include "koneksi.php";
$query = "SELECT *from produk";
$result = mysqli_query($koneksi, $query);
while($row = mysqli_fetch_array($result))
{?>

  <div class="column">
    <div class="card" >
        <img src="gambar/<?php echo $row['url_gambar']; ?>" alt="Avatar" style="width:100%; display: block; height:200px">
      <p><Strong><?php echo $row['nm_produk'];?></Strong></p>
      <p class="harga"> <strong> Rp.<?php  echo " ". number_format($row['harga'], 0, ".", ","); ?></strong></p>
      <button class="btn btn-lg btn-primary btn-block" type="submit" >Beli Sekarang </button>
    </div>
  </div>
  <?php
} 
?>
</div>
</body>
</html>

