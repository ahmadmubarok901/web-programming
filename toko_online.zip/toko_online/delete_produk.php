<?php
include "koneksi.php";

$id=$_GET['id'];

$query = mysqli_query($koneksi, "DELETE FROM PRODUK WHERE id_produk='$id'");

header("location:view_produk.php");


?>