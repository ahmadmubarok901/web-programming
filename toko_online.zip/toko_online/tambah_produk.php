<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="assets/css/bootstrap.css"> 
    <script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script>
<body>
<body>

        <h1>Tambah Produk</h1>

      <form method="POST" action="proses_tambah_produk.php" enctype="multipart/form-data" >
      <span>ID  Produk</span>
        <input class="form-control" type="text" name="id_produk"> <br>
        <span>Nama Produk</span>
        <input  class="form-control" type="text" name="nm_produk"> <br>
        <span>Jenis Produk</span>
        <input  class="form-control" type="text" name="jenis"> <br>
            <br>
        <span>Ukuran</span>
        <input  class="form-control" type="text" name="ukuran"> <br>
         <br>
        <span>Warna</span>
        <input  class="form-control" type="text" name="warna"> <br>
        <span>Harga</span>
        <input class="form-control" type="text" name="harga" id=""> <br>
        <span>Stok</span>
        <input class="form-control" type="text" name="stok" id=""> <br>
        <span>Keterangan</span>
        <input class="form-control" type="text" name="deskripsi" id=""> <br>
        <span>Gambar</span>
        <input class="form-control" type="file" name="url_gambar" id=""> <br>
        <input  class="btn btn-primary" type="submit" value="Simpan">  <input type="reset" value="Reset">
        </form>
</body>
</html>