<?php


include 'koneksi.php';

echo $id_anggota = $_POST['id_anggota'];
echo $username =$_POST['username'];
echo $password = $_POST['password'];
$nm_lengkap = $_POST['nm_lengkap'];
$jk = $_POST['jk'];
$tgl_lahir =  $_POST['tgl_lahir'];
$no_hp = $_POST['no_hp'];
$email = $_POST['email'];
$alamat = $_POST['alamat'];
$status = $_POST['status'];

mysqli_query($koneksi, "Update anggota SET id_anggota='$id_anggota ', username='$username', password='$password', nm_lengkap='$nm_lengkap',
                                        jk='$jk', tgl_lahir='$tgl_lahir', no_hp='$no_hp', email='$email', alamat='$alamat', status='$status' 
                                        WHERE id_anggota='$id_anggota' ");

header("location:view_anggota.php");

?>