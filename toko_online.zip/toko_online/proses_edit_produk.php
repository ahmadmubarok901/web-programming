<?php
// referensi https://gilacoding.com/
include "koneksi.php";

$id_produk = $_POST ['id_produk'];
$nm_produk = $_POST ['nm_produk'];
$jenis  = $_POST ['jenis'];
$ukuran = $_POST ['ukuran'];
$warna = $_POST ['warna'];
$harga = $_POST ['harga'];
$stok = $_POST ['stok'];
$deskripsi = $_POST ['deskripsi'];
$url_gambar = $_FILES ['url_gambar']['name'];


if($url_gambar != "") {
    $ekstensi_diperbolehkan = array('png','jpg'); // ekstensi gambar yang bisa di disimpan
    $x = explode('.', $url_gambar); //memisahkan nama file dengan ekstensi yang diupload
    $ekstensi = strtolower(end($x));
    $file_tmp = $_FILES['url_gambar']['tmp_name'];   
    $angka_acak     = rand(1,999); // melakukan random angkan untuk penamaan file di folder
    $nama_gambar_baru = $angka_acak.'-'. $url_gambar; //menggabungkan angka acak dengan nama file sebenarnya
          if(in_array($ekstensi, $ekstensi_diperbolehkan) === true)  {     
                  move_uploaded_file($file_tmp, 'gambar/'.$nama_gambar_baru); //memindah file  ke folder gambar
                  // Query untuk menyimpan kedalam database

                  $query = "UPDATE  produk SET  id_produk='$id_produk', nm_produk='$nm_produk', jenis='$jenis', ukuran='$ukuran', warna='$warna',
                                                    harga='$harga',  stok='$stok', deskripsi='$deskripsi',  url_gambar='$nama_gambar_baru' WHERE id_produk='$id_produk'";
                                                  
                                         
                  $result = mysqli_query($koneksi, $query);
            
                  if(!$result){
                      die ("Query gagal dijalankan: ".mysqli_errno($koneksi).
                           " - ".mysqli_error($koneksi));
                  } else {
               
                    echo "<script>alert('Data berhasil dirubah.');window.location='view_produk.php';</script>";
                  }

            } else {     
         
                echo "<script>alert('Ekstensi gambar yang boleh hanya jpg atau png.');window.location='tambah_produk.php';</script>";
            }
                    } else {
                        $query = "UPDATE  produk SET  id_produk='$id_produk', nm_produk='$nm_produk', jenis='$jenis', ukuran='$ukuran', warna='$warna',
                                   harga='$harga',  stok='$stok', deskripsi='$deskripsi',  url_gambar='$nama_gambar_baru' WHERE id_produk='$id_produk'";
                      

                    $result = mysqli_query($koneksi, $query);
                                
                                    if(!$result){
                                        die ("Query gagal dijalankan: ".mysqli_errno($koneksi).
                                            " - ".mysqli_error($koneksi));
                                    } else {
         

                    echo "<script>alert('Data berhasil dirubah.');window.location='view_produk.php';</script>";
                  }
}
?>