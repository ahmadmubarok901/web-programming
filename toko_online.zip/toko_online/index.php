<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body leftmargin="50>
    <div class="header"> 
    <div class="navbar">   
    <div style="float:left;">
   
    
    <div class="input-group">
      <h2 style="color: #F6FCF6;"> AMU Strore </h2> &nbsp;
    <input type="search" placeholder="What're you searching for?" aria-describedby="button-addon1" class="form-control border-0 bg-light">
              <div class="input-group-append">
                <button id="button-addon1" type="submit" class="btn btn-link-lg text-primary"> <img src="img/search.png" alt=""> </button>
              </div>
            </div>
    </div>    
    <div style="float:right;">
         <button type="button" class="btn btn-info">Masuk</button>
         <button type="button" class="btn btn-info">Daftar</button>
    </div>
    </div>
    </div>

    <br>
    <h2>Pilih Kategori</h2>
    <div class="card-group">
      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/buku.png" style="width: 100%; height:100%; display:block; border-radius:10px; "alt=""> </a>
      </div>

   
      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/elektronik.png" style="width: 100%; height:100%; display:block; border-radius:10px; "  alt=""> </a>
      </div>

     
      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/fashion.png" style="width: 100%; height:100%; display:block; border-radius:10px; "  alt=""> </a>
      </div>


      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/otomotiv.png" style="width: 100%; height:100%; display:block; border-radius:10px; "  alt=""> </a>
      </div>

      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/gadget.png" style="width: 100%; height:100%; display:block; border-radius:10px; "  alt=""> </a>
      </div>

      
      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/dapur.png" style="width: 100%; height:100%; display:block; border-radius:10px; "  alt=""> </a>
      </div>

      
      <div class="card shadow p-3 mb-5 bg-indianred" style="height: auto; width:auto;">
          <a href="produk.php" target="new"> <img src="img/sayur.png" style="width: 100%; height:100%; display:block; border-radius:10px;"  alt=""> </a>
      </div>

    </div>
    
    <?php
    echo " <h2> Produk Terbaru </h2>";
    include "produk_home.php";
    ?>
</body>
</html>